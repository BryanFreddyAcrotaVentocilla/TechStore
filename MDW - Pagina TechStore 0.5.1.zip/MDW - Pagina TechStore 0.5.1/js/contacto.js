document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('formContacto');
    const alerta = document.getElementById('alertaContacto');
    if (!form) return;

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        alerta.className = 'alert alert-success mt-3';
        alerta.textContent = 'Mensaje enviado correctamente. Te responderemos pronto.';
        alerta.classList.remove('d-none');
        form.reset();
    });
});
