const STORAGE_KEY = "techstore_productos";
const CARRITO_KEY = "techstore_carrito";

const categorias = ["Tecnología", "Prearmados", "Componentes"];

const productosDefault = [
  { nombre: "Iphone 12", categoria: "Tecnología", precio: 899, imagen: "img/Iphone12.png", descripcion: "128GB / 8GB RAM", especificaciones: ["Pantalla Super Retina XDR", "Almacenamiento: 128GB", "Memoria RAM: 8GB", "Conectividad 5G"] },
  { nombre: "Reloj Inteligente", categoria: "Tecnología", precio: 149, imagen: "img/RelojInteligente.png", descripcion: "Pantalla AMOLED y batería de 96h", especificaciones: ["Pantalla AMOLED", "Batería: hasta 96 horas", "Monitoreo deportivo", "Bluetooth"] },
  { nombre: "Micrófono Profesional", categoria: "Tecnología", precio: 199, imagen: "img/MicrofonoProfesional.png", descripcion: "Audio claro para streaming y grabación", especificaciones: ["Conexión USB", "Soporte de 1.5m", "Patrón cardioide", "Ideal para streaming"] },
  { nombre: "Audífonos Ergonómicos", categoria: "Tecnología", precio: 129, imagen: "img/AudicularesErgonomicos.png", descripcion: "Sonido premium con cancelación", especificaciones: ["Cancelación de ruido", "Conexión Bluetooth", "Micrófono integrado", "Diseño ergonómico"] },
  { nombre: "PlayStation 5 Pro", categoria: "Tecnología", precio: 1699, imagen: "img/PlayStation5Pro.png", descripcion: "Consola de última generación", especificaciones: ["SSD de alta velocidad", "Resolución hasta 4K", "1TB de almacenamiento", "Control inalámbrico"] },
  { nombre: "Laptop ASUS", categoria: "Prearmados", precio: 1299, imagen: "img/LaptopASUS.png", descripcion: "Ideal para trabajo y estudio", especificaciones: ["Pantalla Full HD", "16GB RAM", "SSD 512GB", "Procesador Intel Core i5"] },
  { nombre: "Workstation 3D", categoria: "Prearmados", precio: 1799, imagen: "img/Workstation3D.png", descripcion: "Diseñada para render y diseño 3D", especificaciones: ["32GB RAM", "SSD 1TB", "GPU dedicada", "Recomendada para diseño 3D"] },
  { nombre: "PC Office Pro", categoria: "Prearmados", precio: 949, imagen: "img/PCOfficePro.png", descripcion: "Rendimiento para oficina y multitarea", especificaciones: ["16GB RAM", "SSD 512GB", "Wi-Fi", "Uso empresarial y académico"] },
  { nombre: "PC Gamer Ryzen 7", categoria: "Prearmados", precio: 1699, imagen: "img/PCGamerRyzen7.png", descripcion: "Gaming y edición sin límites", especificaciones: ["Ryzen 7", "32GB RAM", "SSD 1TB", "Tarjeta gráfica dedicada"] },
  { nombre: "Mini PC Compact", categoria: "Prearmados", precio: 799, imagen: "img/MiniPCCompact.png", descripcion: "Potencia compacta y silenciosa", especificaciones: ["16GB RAM", "SSD 512GB", "Diseño compacto", "Bajo consumo energético"] },
  { nombre: "Procesador Ryzen 5 5600", categoria: "Componentes", precio: 229, imagen: "img/ProcesadorRyzen55600.png", descripcion: "6 núcleos / 12 hilos", especificaciones: ["6 núcleos", "12 hilos", "Socket AM4", "Arquitectura Zen 3"] },
  { nombre: "RTX 4060", categoria: "Componentes", precio: 599, imagen: "img/TarjetaGraficaRTX4060.png", descripcion: "Ray tracing y 1080p ultra", especificaciones: ["8GB GDDR6", "Ray Tracing", "DLSS", "Ideal para gaming 1080p"] },
  { nombre: "Memoria RAM 32GB", categoria: "Componentes", precio: 189, imagen: "img/MemoriaRAM32GB.png", descripcion: "16x2 DDR5 3200MHz", especificaciones: ["Capacidad: 32GB", "Tipo: DDR5", "Velocidad: 3200MHz", "Kit de memoria"] },
  { nombre: "SSD 1TB", categoria: "Componentes", precio: 119, imagen: "img/AlmacenamientoSSD1TB.png", descripcion: "Velocidad y espacio para todo", especificaciones: ["Capacidad: 1TB", "Lectura: hasta 3500MB/s", "Formato M.2", "Alta velocidad"] },
  { nombre: "Placa Base B550", categoria: "Componentes", precio: 249, imagen: "img/PlacabaseB550.png", descripcion: "Compatibilidad total con Ryzen", especificaciones: ["Chipset B550", "Socket AM4", "Compatible con Ryzen", "Wi-Fi integrado"] }
];

let productos = [];
let carrito = [];
let productoSeleccionado = null;
let modalDetalle;
let modalCarrito;

function imagenFallback(producto) {
    const texto = encodeURIComponent((producto.nombre || "Producto").substring(0, 18));
    return `data:image/svg+xml;charset=UTF-8,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="450"><rect width="100%" height="100%" fill="%23f1f5f9"/><rect x="45" y="45" width="510" height="360" rx="24" fill="%23e2e8f0"/><text x="300" y="220" text-anchor="middle" font-family="Arial" font-size="34" font-weight="bold" fill="%23475569">${texto}</text><text x="300" y="265" text-anchor="middle" font-family="Arial" font-size="20" fill="%2364758b">TechStore</text></svg>`;
}

function prepararImagen(img, producto) {
    img.onerror = () => {
        img.onerror = null;
        img.src = imagenFallback(producto);
    };
}

function cargarProductos() {
    const guardados = localStorage.getItem(STORAGE_KEY);
    if (guardados) {
        try {
            const datos = JSON.parse(guardados);
            if (Array.isArray(datos) && datos.length) {
                productos = datos;
                completarEspecificaciones();
                mostrarProductos();
                return;
            }
        } catch (e) {}
    }
    productos = productosDefault.map(p => ({ ...p, especificaciones: [...p.especificaciones] }));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(productos));
    mostrarProductos();
}

function completarEspecificaciones() {
    productos.forEach(producto => {
        if (!Array.isArray(producto.especificaciones) || producto.especificaciones.length === 0) {
            const original = productosDefault.find(p => p.nombre === producto.nombre);
            producto.especificaciones = original ? [...original.especificaciones] : [producto.descripcion || "Producto tecnológico"];
        }
    });
}

function mostrarProductos() {
    const contenedor = document.getElementById("productos");
    if (!contenedor) return;
    contenedor.innerHTML = "";

    categorias.forEach(categoria => {
        const items = productos.filter(p => p.categoria === categoria);
        if (!items.length) return;

        const color = categoria === "Prearmados" ? "bg-primary" : categoria === "Componentes" ? "bg-success" : "bg-secondary";
        const seccion = document.createElement("div");
        seccion.className = "col-12";
        seccion.innerHTML = `<div class="card border-0 shadow-sm overflow-hidden"><div class="card-header ${color} text-white"><h2 class="h5 mb-0">${categoria}</h2></div><div class="card-body"><div class="row g-3"></div></div></div>`;
        const fila = seccion.querySelector(".row");

        items.forEach(producto => {
            const index = productos.indexOf(producto);
            const tarjeta = document.createElement("div");
            tarjeta.className = "col-xl-3 col-lg-4 col-md-6";
            tarjeta.innerHTML = `<div class="card producto-card h-100 border-0 shadow-sm"><div class="img-box"><img src="${producto.imagen}" alt="${producto.nombre}"></div><div class="card-body d-flex flex-column"><h3 class="h6 fw-bold">${producto.nombre}</h3><p class="small text-muted mb-3">${producto.descripcion || ""}</p><div class="mt-auto"><div class="d-flex justify-content-between align-items-center mb-3"><span class="fw-bold text-primary">S/${Number(producto.precio).toFixed(2)}</span></div><button class="btn btn-sm btn-outline-primary w-100 detalle-btn">Ver detalle</button></div></div></div>`;
            prepararImagen(tarjeta.querySelector("img"), producto);
            tarjeta.querySelector(".detalle-btn").addEventListener("click", () => abrirDetalle(index));
            fila.appendChild(tarjeta);
        });
        contenedor.appendChild(seccion);
    });
}

function abrirDetalle(index) {
    productoSeleccionado = productos[index];
    if (!productoSeleccionado) return;
    document.getElementById("detalleTitulo").textContent = "Detalle del producto";
    document.getElementById("detalleNombre").textContent = productoSeleccionado.nombre;
    document.getElementById("detalleCategoria").textContent = productoSeleccionado.categoria;
    document.getElementById("detalleDescripcion").textContent = productoSeleccionado.descripcion || "";
    document.getElementById("detallePrecio").textContent = `S/${Number(productoSeleccionado.precio).toFixed(2)}`;
    const img = document.getElementById("detalleImagen");
    img.src = productoSeleccionado.imagen;
    img.alt = productoSeleccionado.nombre;
    prepararImagen(img, productoSeleccionado);
    const lista = document.getElementById("detalleEspecificaciones");
    lista.innerHTML = "";
    (productoSeleccionado.especificaciones || []).forEach(e => {
        const li = document.createElement("li");
        li.className = "list-group-item px-0";
        li.innerHTML = `<span class="me-2 text-primary">✓</span>${e}`;
        lista.appendChild(li);
    });
    modalDetalle.show();
}

function cargarCarrito() {
    try {
        const guardado = JSON.parse(localStorage.getItem(CARRITO_KEY));
        carrito = Array.isArray(guardado) ? guardado : [];
    } catch (e) {
        carrito = [];
    }
    actualizarContador();
}

function guardarCarrito() {
    localStorage.setItem(CARRITO_KEY, JSON.stringify(carrito));
    actualizarContador();
}

function agregarAlCarrito(producto) {
    if (!producto) return;

    // Se identifica por nombre porque los productos del catálogo no tienen id.
    const existente = carrito.find(item => item.nombre === producto.nombre);

    if (existente) {
        existente.cantidad += 1;
    } else {
        carrito.push({
            nombre: producto.nombre,
            precio: Number(producto.precio) || 0,
            imagen: producto.imagen || "",
            cantidad: 1
        });
    }

    guardarCarrito();
    renderCarrito();
    mostrarToast(`${producto.nombre} agregado al carrito.`);
}

function renderCarrito() {
    const lista = document.getElementById("listaCarrito");
    const vacio = document.getElementById("carritoVacio");
    const total = document.getElementById("totalCarrito");
    if (!lista || !vacio || !total) return;

    lista.innerHTML = "";

    if (carrito.length === 0) {
        vacio.classList.remove("d-none");
        total.textContent = "S/0.00";
        return;
    }

    vacio.classList.add("d-none");
    let totalCompra = 0;

    carrito.forEach((item, index) => {
        const precio = Number(item.precio) || 0;
        const cantidad = Number(item.cantidad) || 1;
        const subtotal = precio * cantidad;
        totalCompra += subtotal;

        const fila = document.createElement("div");
        fila.className = "carrito-item border rounded-3 p-3 mb-3";
        fila.innerHTML = `<div class="row align-items-center g-3"><div class="col-3 col-sm-2 text-center"><img class="carrito-imagen" src="${item.imagen}" alt="${item.nombre}"></div><div class="col-9 col-sm-4"><h6 class="mb-1">${item.nombre}</h6><small class="text-muted">S/${precio.toFixed(2)} c/u</small></div><div class="col-7 col-sm-4"><div class="input-group input-group-sm cantidad-control"><button class="btn btn-outline-secondary btn-restar">−</button><input class="form-control text-center" value="${cantidad}" readonly><button class="btn btn-outline-secondary btn-sumar">+</button></div></div><div class="col-5 col-sm-2 text-end"><div class="fw-bold text-primary mb-2">S/${subtotal.toFixed(2)}</div><button class="btn btn-sm btn-outline-danger btn-eliminar">Eliminar</button></div></div>`;
        prepararImagen(fila.querySelector("img"), item);
        fila.querySelector(".btn-restar").addEventListener("click", () => cambiarCantidad(index, -1));
        fila.querySelector(".btn-sumar").addEventListener("click", () => cambiarCantidad(index, 1));
        fila.querySelector(".btn-eliminar").addEventListener("click", () => eliminarDelCarrito(index));
        lista.appendChild(fila);
    });

    total.textContent = `S/${totalCompra.toFixed(2)}`;
}

function cambiarCantidad(index, cambio) {
    if (!carrito[index]) return;
    carrito[index].cantidad = (Number(carrito[index].cantidad) || 1) + cambio;
    if (carrito[index].cantidad <= 0) carrito.splice(index, 1);
    guardarCarrito();
    renderCarrito();
}

function eliminarDelCarrito(index) {
    carrito.splice(index, 1);
    guardarCarrito();
    renderCarrito();
}

function vaciarCarrito() {
    carrito = [];
    guardarCarrito();
    renderCarrito();
}

function actualizarContador() {
    const contador = document.getElementById("contadorCarrito");
    if (!contador) return;
    const cantidad = carrito.reduce((total, item) => total + (Number(item.cantidad) || 0), 0);
    contador.textContent = cantidad;
}

function mostrarToast(mensaje) {
    const toast = document.getElementById("toastCarrito");
    const mensajeElemento = document.getElementById("toastMensaje");
    if (!toast || !mensajeElemento || typeof bootstrap === "undefined") return;
    mensajeElemento.textContent = mensaje;
    bootstrap.Toast.getOrCreateInstance(toast, { delay: 2200 }).show();
}

document.addEventListener("DOMContentLoaded", () => {
    modalDetalle = new bootstrap.Modal(document.getElementById("modalDetalle"));
    modalCarrito = new bootstrap.Modal(document.getElementById("modalCarrito"));

    document.getElementById("btnAgregarDetalle").addEventListener("click", () => {
        if (!productoSeleccionado) return;
        agregarAlCarrito(productoSeleccionado);
        modalDetalle.hide();
    });

    document.getElementById("btnCarrito").addEventListener("click", event => {
        event.preventDefault();
        // Siempre mostramos el contenido actual del carrito al abrirlo.
        renderCarrito();
        modalCarrito.show();
    });

    document.getElementById("btnVaciarCarrito").addEventListener("click", () => {
        if (carrito.length === 0) return;
        vaciarCarrito();
    });

    document.getElementById("btnFinalizarCompra").addEventListener("click", () => {
        if (!carrito.length) {
            mostrarToast("Agrega al menos un producto para continuar.");
            return;
        }
        mostrarToast("Compra preparada. Puedes continuar con el proceso de pago.");
    });

    cargarProductos();
    cargarCarrito();
    renderCarrito();
});
