const STORAGE_KEY = "techstore_productos";

const categorias = ["Tecnología", "Prearmados", "Componentes"];

const productosDefault = [
  { nombre: "Iphone 12", categoria: "Tecnología", precio: 899, imagen: "img/Iphone12.png", descripcion: "128GB / 8GB RAM" },
  { nombre: "Reloj Inteligente", categoria: "Tecnología", precio: 149, imagen: "img/RelojInteligente.png", descripcion: "Pantalla AMOLED y batería de 96h" },
  { nombre: "Micrófono Profesional", categoria: "Tecnología", precio: 199, imagen: "img/MicrofonoProfesional.png", descripcion: "Audio claro para streaming y grabación" },
  { nombre: "Audífonos Ergonómicos", categoria: "Tecnología", precio: 129, imagen: "img/AudicularesErgonomicos.png", descripcion: "Sonido premium con cancelación" },
  { nombre: "PlayStation 5 Pro", categoria: "Tecnología", precio: 1699, imagen: "img/PlayStation5Pro.png", descripcion: "Consola de última generación" },

  { nombre: "Laptop ASUS", categoria: "Prearmados", precio: 1299, imagen: "img/LaptopASUS.png", descripcion: "Ideal para trabajo y estudio" },
  { nombre: "Workstation 3D", categoria: "Prearmados", precio: 1799, imagen: "img/Workstation3D.png", descripcion: "Diseñada para render y diseño 3D" },
  { nombre: "PC Office Pro", categoria: "Prearmados", precio: 949, imagen: "img/PCOfficePro.png", descripcion: "Rendimiento para oficina y multitarea" },
  { nombre: "PC Gamer Ryzen 7", categoria: "Prearmados", precio: 1699, imagen: "img/PCGamerRyzen7.png", descripcion: "Gaming y edición sin límites" },
  { nombre: "Mini PC Compact", categoria: "Prearmados", precio: 799, imagen: "img/MiniPCCompact.png", descripcion: "Potencia compacta y silenciosa" },

  { nombre: "Procesador Ryzen 5 5600", categoria: "Componentes", precio: 229, imagen: "img/ProcesadorRyzen55600.png", descripcion: "6 núcleos / 12 hilos" },
  { nombre: "RTX 4060", categoria: "Componentes", precio: 599, imagen: "img/TarjetaGraficaRTX4060.png", descripcion: "Ray tracing y 1080p ultra" },
  { nombre: "Memoria RAM 32GB", categoria: "Componentes", precio: 189, imagen: "img/MemoriaRAM32GB.png", descripcion: "DDR4 3200MHz" },
  { nombre: "SSD 1TB", categoria: "Componentes", precio: 119, imagen: "img/AlmacenamientoSSD1TB.png", descripcion: "Velocidad y espacio para todo" },
  { nombre: "Placa Base B550", categoria: "Componentes", precio: 249, imagen: "img/PlacabaseB550.png", descripcion: "Compatibilidad total con Ryzen" }
];

let productos = [];

const alerta = document.getElementById("alerta");
const listaProductos = document.getElementById("listaProductos");
const formProducto = document.getElementById("formProducto");
const productoIndex = document.getElementById("productoIndex");
const nombreInput = document.getElementById("nombre");
const categoriaInput = document.getElementById("categoria");
const precioInput = document.getElementById("precio");
const imagenInput = document.getElementById("imagen");
const descripcionInput = document.getElementById("descripcion");

function mostrarAlerta(mensaje, tipo) {
  alerta.className = "alert alert-" + tipo + " mt-3";
  alerta.textContent = mensaje;
  alerta.classList.remove("d-none");
}

function ocultarAlerta() {
  alerta.classList.add("d-none");
}

function guardarLocalStorage() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(productos));
}

function limpiarFormulario() {
  formProducto.reset();
  productoIndex.value = "";
  ocultarAlerta();
}

function cargarProductosIniciales() {
  const guardados = localStorage.getItem(STORAGE_KEY);

  if (guardados) {
    try {
      const datos = JSON.parse(guardados);
      if (Array.isArray(datos) && datos.length > 0) {
        productos = datos;
        mostrarProductos();
        return;
      }
    } catch (error) {
      console.log("No se pudo leer localStorage");
    }
  }

  /*Si no hay datos guardados, intenta leer productos.txt*/
  fetch("js/productos.txt")
    .then(response => {
      if (!response.ok) throw new Error("No existe el archivo");
      return response.json();
    })
    .then(data => {
      if (Array.isArray(data) && data.length > 0) {
        productos = data;
        guardarLocalStorage();
        mostrarProductos();
      } else {
        productos = productosDefault;
        guardarLocalStorage();
        mostrarProductos();
      }
    })
    .catch(() => {
      productos = productosDefault;
      guardarLocalStorage();
      mostrarProductos();
    });
}

function mostrarProductos() {
  listaProductos.innerHTML = "";

  categorias.forEach(categoria => {
    const items = productos.filter(producto => producto.categoria === categoria);

    if (items.length === 0) return;

    let color = "bg-secondary";
    if (categoria === "Prearmados") color = "bg-primary";
    if (categoria === "Componentes") color = "bg-success";

    let contenido = `
      <div class="col-12">
        <div class="card border-0 shadow-sm overflow-hidden">
          <div class="card-header ${color} text-white">
            <h3 class="h5 mb-0">${categoria}</h3>
          </div>
          <div class="card-body">
            <div class="row g-3">
    `;

    items.forEach(producto => {
      const index = productos.indexOf(producto);

      contenido += `
        <div class="col-xl-3 col-lg-4 col-md-6">
          <div class="card h-100 border-0 shadow-sm">
            <div class="img-box">
              <img src="${producto.imagen}" alt="${producto.nombre}" style="max-width:100%; max-height:180px; object-fit:contain;">
            </div>
            <div class="card-body d-flex flex-column">
              <h4 class="h6">${producto.nombre}</h4>
              <p class="small text-muted mb-3">${producto.descripcion}</p>

              <div class="mt-auto">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <span class="fw-bold text-primary">$${Number(producto.precio).toFixed(2)}</span>
                </div>

                <div class="d-flex gap-2">
                  <button class="btn btn-sm btn-primary flex-fill editar-btn" data-index="${index}">
                    Editar
                  </button>
                  <button class="btn btn-sm btn-outline-danger flex-fill eliminar-btn" data-index="${index}">
                    Eliminar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
    });

    contenido += `
            </div>
          </div>
        </div>
      </div>
    `;

    listaProductos.insertAdjacentHTML("beforeend", contenido);
  });

  document.querySelectorAll(".editar-btn").forEach(boton => {
    boton.addEventListener("click", function () {
      const index = Number(this.dataset.index);
      editarProducto(index);
    });
  });

  document.querySelectorAll(".eliminar-btn").forEach(boton => {
    boton.addEventListener("click", function () {
      const index = Number(this.dataset.index);
      eliminarProducto(index);
    });
  });
}

function guardarProducto(event) {
  event.preventDefault();

  const producto = {
    nombre: nombreInput.value.trim(),
    categoria: categoriaInput.value,
    precio: Number(precioInput.value),
    imagen: imagenInput.value.trim(),
    descripcion: descripcionInput.value.trim()
  };

  if (!producto.nombre || !producto.imagen || !producto.descripcion || !producto.precio) {
    mostrarAlerta("Completa todos los campos.", "danger");
    return;
  }

  const index = productoIndex.value;

  if (index === "") {
    productos.push(producto);
    mostrarAlerta("Producto agregado correctamente.", "success");
  } else {
    productos[Number(index)] = producto;
    mostrarAlerta("Producto actualizado correctamente.", "warning");
  }

  guardarLocalStorage();
  mostrarProductos();
  limpiarFormulario();
}

function editarProducto(index) {
  const producto = productos[index];

  productoIndex.value = index;
  nombreInput.value = producto.nombre;
  categoriaInput.value = producto.categoria;
  precioInput.value = producto.precio;
  imagenInput.value = producto.imagen;
  descripcionInput.value = producto.descripcion;

  mostrarAlerta("Editando producto seleccionado.", "info");
  nombreInput.focus();
}

function eliminarProducto(index) {
  productos.splice(index, 1);
  guardarLocalStorage();
  mostrarProductos();
  mostrarAlerta("Producto eliminado.", "danger");
}

function descargarTXT() {
  const texto = JSON.stringify(productos, null, 2);

  const blob = new Blob([texto], { type: "text/plain;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "productos.txt";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  mostrarAlerta("Archivo productos.txt descargado.", "success");
}

function cargarTXT(event) {
  const archivo = event.target.files[0];

  if (!archivo) return;

  const lector = new FileReader();

  lector.onload = function (e) {
    try {
      const data = JSON.parse(e.target.result);

      if (!Array.isArray(data)) {
        throw new Error("No es un arreglo");
      }

      productos = data;
      guardarLocalStorage();
      mostrarProductos();
      mostrarAlerta("Productos cargados desde el archivo.", "success");
    } catch (error) {
      mostrarAlerta("El archivo no es válido. Debe ser JSON.", "danger");
    }
  };

  lector.readAsText(archivo);
}

document.getElementById("btnNuevo").addEventListener("click", limpiarFormulario);
document.getElementById("btnCancelar").addEventListener("click", limpiarFormulario);
formProducto.addEventListener("submit", guardarProducto);
document.getElementById("btnGuardarTxt").addEventListener("click", descargarTXT);
document.getElementById("inputArchivo").addEventListener("change", cargarTXT);

document.addEventListener("DOMContentLoaded", cargarProductosIniciales);